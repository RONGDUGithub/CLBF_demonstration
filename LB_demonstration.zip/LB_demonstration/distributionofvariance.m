function [var_s2,varX]=distributionofvariance(epsilon,n)
%调用数值解
% epsilon=1/5;
% n=70;k
% [varX,kurt]=fengdu_shuzhi(epsilon);
% var_s2=power(varX,2)/n*(kurt-1+2/(n-1))
% 
% epsilon=1/4;
% n=80;
[varX,kurt,meanX]=fengdu_shuzhi(epsilon);
%总体方差，这里要想出一个说法
     var_s2=power(varX,2)/n*(kurt-1+2/(n-1))*n;
end