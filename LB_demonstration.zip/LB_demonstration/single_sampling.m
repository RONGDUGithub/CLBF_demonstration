function final1=single_sampling(y0,w_event_size,query_size,epsilon)
h=query_size;
%query_size();
final0=zeros(2,6);
j=0;
smooth_size=3;

for i=1:1:100
 j=j+1;
 
 y=y0(i:i+h-1);
         if query_size<w_event_size
             t_size=query_size;
             flag=1;
        else
              flag=2;
             t_size=w_event_size;
         end
        epsilon_windows_baseline=epsilon/t_size;
       epsilon_windows_SW=epsilon_windows_baseline;
 [epsilon_sampling,y_flag,sampling_number]=numberofsampling(query_size,t_size,epsilon);

 %epsilon_windows_SW = epsilon/query_size;
 %sampling_number=9;
body;
% mean_final = mean(Cos1_round);
distribution_error=distribution_final; 
final0=final0+final;
end
final1=final0/j;
end


