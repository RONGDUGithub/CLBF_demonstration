function mappedValue = mapToRange2(inputValue)
    % 检查输入值是否在 [0, 1] 之间
    if inputValue < 0 || inputValue > 1
        error('输入值必须在 [0, 1] 区间内');
    end
    
    % 映射到 [-1, 1] 的公式为：mappedValue = inputValue * 2 - 1;
    mappedValue = inputValue * 2 - 1;
end