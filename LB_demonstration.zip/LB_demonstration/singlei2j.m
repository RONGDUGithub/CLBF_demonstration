
function final2=singlei2j(yy,w_event_size,epsilon)

y0 = normalize(yy, 'range', [0, 1]);

query_size=w_event_size;  
h=query_size;


final0=zeros(2,5);

j=0;
smooth_size=3;
for i=1:h:length(yy)-2*w_event_size
    j=j+1;
    y=y0(i:i+w_event_size-1);
    list2;
    final0=final0+final;
end

final2=final0/j;
 end

