clear all;

suffix='Single1';
load('air.mat');
filename='Air';

yy=air_c6h6';

w_event_size=20;
platform_single_procedure;
