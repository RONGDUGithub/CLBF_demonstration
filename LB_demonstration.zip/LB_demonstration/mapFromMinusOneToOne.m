function mappedValue = mapFromMinusOneToOne(inputValue)
    % 检查输入值是否在 [-1, 1] 之间
%     if inputValue < -1 || inputValue > 1
%         error('输入值必须在 [-1, 1] 区间内');
%     end
%     
    % 映射到 [0, 1] 的公式为：mappedValue = (inputValue + 1) / 2;
    mappedValue = (inputValue + 1) / 2;
end