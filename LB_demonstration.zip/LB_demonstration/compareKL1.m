function D_kl_a = compareKL1(y, yp_vector) 
 [rows, cols] = size(yp_vector);

short_edge = rows;
 D_kl_a =zeros(1,rows);

 for r=1:rows

     yp_vector0=yp_vector(r,:);

  D_kl_a(r)=cosineSim(y,yp_vector0); 
end
 
end