function yg=SW_sampling_dynamic2(y,epsilon_single,y_flag)
ytemp=y;
y= generate_yg(ytemp, y_flag);

number=length(y);
yp_vector_SW2=zeros(1,number);
Error_vector_SW2=zeros();
error_vector_ac=zeros();
initial=y(1);
%第一个数不需要设置默认
y_prime_SW2=SW(initial,epsilon_single);
yp_vector_SW2(1)=y_prime_SW2;
x_bar=y_prime_SW2;
last=y_prime_SW2;
error0=0;
Error_vector_SW2(1)=0;

    windows_size2=sum(y_flag);
    
    
yp_vector_SW3=SW_sequence_dynamic_test(y,windows_size2,epsilon_single);
       yg = generate_yg2(yp_vector_SW3, y_flag);
end