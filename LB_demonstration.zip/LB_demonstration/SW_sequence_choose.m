function yp_vector_SW2=SW_sequence_choose(y,windows_size,epsilon,epsilon_windows_SW,index)
% if index==1
%    yp_vector_SW2=SW2_sequence(y,windows_size,epsilon,epsilon_windows_SW);
% end
% 
% if index==2
%   yp_vector_SW2=SW_sequence_dynamic(y,windows_size,epsilon,epsilon_windows_SW);
% end
% 
if index==3
   yp_vector_SW2=SW2_sequence_all(y,windows_size,epsilon_windows_SW);
end
if index==4
  yp_vector_SW2=SW_sequence_dynamic_test(y,windows_size,epsilon_windows_SW);
end
end