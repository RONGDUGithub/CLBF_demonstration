function [varX,kurt,meanX]=fengdu_shuzhi(epsilon)
% 定义参数
%epsilon = 1/4;  
e = exp(epsilon);
S = (epsilon*e - e + 1)/(2*e*(e-1-epsilon));
p = e/(2*S*e+1);
q = 1/(2*S*e+1);
b=1;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
% 生成分布取值
x = -S:0.00001:S+1;  

% 计算概率密度函数,这里是啥，我有点晕
% 这里是因为不管输入是啥，都服从这个分布

f = zeros(size(x));
f(x>-S & x<=-S+b) = q; 
f(x>=-S+b & x<=S+b) = p;
f(x>b+S&x<1+S) = q;

% 计算均值
meanX = sum(x.*f)/sum(f);

% 计算方差
varX = sum((x-meanX).^2.*f)/sum(f);

% 计算四阶中心矩
mom4 = sum((x-meanX).^4.*f)/sum(f);

% 计算峰度
kurt = mom4/varX^2;
% peakness = kurt - 3;
%mean_devation=abs(meanX-b);
%disp(['该分布的峰度为:', num2str(kurt)]);
end