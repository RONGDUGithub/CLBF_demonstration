function yg = generate_yg(y, flag)
yg = zeros(1,sum(flag));  % 初始化 yg 向量为与 y 向量相同大小的全零向量
j=1;
a=[];
for i = 1:length(flag)
    if flag(i) == 1
        b=[y(i),a];
        yg(j) = mean(b);
        j=j+1;
        a=[];
    else
        a=[a,y(i)];
    end
end
end