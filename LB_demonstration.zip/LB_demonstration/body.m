y2=zeros();
smooth_size=3;
 
round=100;
Error_vector = zeros();
E1_round = zeros(round,6);
Cos1_round = zeros(round,6);
E1_smothing = zeros(round,6);
Cos1_smothing = zeros(round,6);

for ii = 1:round
if query_size<w_event_size
    epsilon_windows_baseline=epsilon/query_size;
    y_flag_base=zeros(1,query_size)+1;
else
    epsilon_windows_baseline=epsilon/w_event_size;
    y_flag_base=zeros(1,query_size)+1;
end

 
basevalue=SW_sequence(y,epsilon_windows_baseline);

yp_vector_SW=SW_sequence_sampling_naive_average(y,epsilon_sampling,y_flag);



index = 3;
windows_size2 = length(y);
yp_vector_SW1 = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_baseline,index);


index = 4;
windows_size2 = length(y);
yp_vector_SW2 = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_baseline,index);



index = 1;
yp_vector_SW3 = SW_sampling_choose2(y,epsilon_sampling,index,y_flag);


index = 2;
yp_vector_SW4 = SW_sampling_choose2(y,epsilon_sampling,index,y_flag);
kl=length(yp_vector_SW);


test_sum_vector0 = [yp_vector_SW;basevalue;yp_vector_SW1;yp_vector_SW2;yp_vector_SW3;yp_vector_SW4];

err_SW_vector = window_error(y,test_sum_vector0);
E1_round(ii,:) = err_SW_vector;

D_KL1 =compareKL1(y, test_sum_vector0);
Cos1_round(ii,:) = D_KL1;

[E2_round(ii,:),Cos2_round(ii,:)]=smoothing_step2(y,test_sum_vector0,smooth_size);

end

Cos3_final=[Cos1_round(1:2),Cos2_round(3:6)];

distribution_final=mean(Cos3_final);


mean_final = mean(E1_round);


final=[mean_final;Cos3_final];
