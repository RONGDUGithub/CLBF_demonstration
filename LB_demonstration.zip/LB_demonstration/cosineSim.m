function sim = cosineSim(x, y) 

sim = dot(x,y) / (norm(x) * norm(y));

end