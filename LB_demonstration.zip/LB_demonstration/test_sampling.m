function [flag,flag_num]=test_sampling(query_size,windows_size,sampling_number)
t_size=windows_size;
%不一定非要均匀
y_flag=zeros(1,query_size)+1;


%均匀分布，具体来说，就是最后一
% 个位置分配一个，前面均匀分配，发送数据的时候，要相应的进行，均值改变
% 每个windows里分配sampling_number个数据
zeros_number=floor(t_size-sampling_number);

y1 = mod(windows_size,sampling_number);
y2 = floor(windows_size/sampling_number);

y_vector=zeros(1,y2);
%每y个，添加一个0,设置一个基本单位
y_vector(1)=1;

z1=mod(query_size,y2);
z2=floor(query_size/y2);

b1 = repmat(y_vector,1,z2);
b2=[b1,b1(1:z1)];

flag = fliplr(b2);
flag_num=sum(flag);
end
% 
% if zeros_number==0
%    % tempz=1;
% else
%     max_blank=blank_number(query_size,zeros_number);
%     tempz=floor(query_size/max_blank);
%     tempy=1;
% for jj=1:query_size
%     y_flag(tempy)=0;
%     tempy=tempy+tempz;
%     if tempy>query_size
%         break;
%     end
% end
% end
% y_flag