function [lower_bound, upper_bound]=Nx(epsilon,x)
x=0.5;
[fx,var1]=para_Gaussin(epsilon,x);
mean=fx;
std_dev=var1;
confidence_level=0.99;
[lower_bound, upper_bound] = confidence_interval(mean, std_dev, confidence_level);

% lower_bound=fx;
% upper_bound=fx;

if lower_bound>0
    lower_bound=0;
end
%upper_bound]
if upper_bound<1
    upper_bound=1;
end
end