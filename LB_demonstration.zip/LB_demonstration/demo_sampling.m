clear all;
%dbstop if all error
suffix='Single2';
load('volume.mat');
filename='volume';
yy=volume';

platform_single2_pre;


w_event_size=20;
query_size=10;
platform_single2_procedure;

