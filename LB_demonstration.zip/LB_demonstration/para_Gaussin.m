function [fx,var1]=para_Gaussin(epsilon,x) 
e=exp(epsilon);
S=(epsilon*e-e+1)/(2*e*(e-1-epsilon));
p=e/(2*S*e+1);
q=1/(2*S*e+1);

fx =q/2*(S^2-(-1-S+x)^2+(S+x)^2-S^2);
%ga1=expand(fx)



fx2=q/3*((-1*S)^3-(-1-S+x)^3+(S+x)^3-S^3+S^3-(-S)^3);
%ga2=expand(fx2)
    

var1=fx2-fx^2;

%ga3=expand(var1);
end
