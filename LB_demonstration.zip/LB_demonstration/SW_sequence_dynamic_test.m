function yp_vector_SW2=SW_sequence_dynamic_test(y,vector_smooth,epsilon_single)
number=length(y);
yp_vector_SW2=zeros(1,number);
Error_vector_SW2=zeros();
error_vector_ac=zeros();
initial=y(1);
Error_vector_SW2(1)=0;
lower_bound=0;   
upper_bound=1;
for i=1:number
    initial=y(i);
    error0=0;
    windows_size2=vector_smooth;
    if i<=windows_size2
        error0=sum(Error_vector_SW2(1:i-1));
    else
        error0=sum(Error_vector_SW2(i-windows_size2:i-1));
    end                  
%    error_vector_ac(i)=error0;  
    initial_error=initial+error0;
  x_bar=mean(yp_vector_SW2(1:i));
 [lower_bound, upper_bound]=Nx(epsilon_single,x_bar);
 al=b_range(epsilon_single,number);
 %al=0;
 %al=-0.03;
 %al=0.0213;
 lower_bound=0-al;
 upper_bound=1+al;
 
    t=compressDatah(initial_error, lower_bound, upper_bound);
    if t>1
        t=1;
    else
        if t<0
         t=0;
        end
    end
    
     t_temp=SW(t,epsilon_single);
     y_prime_SW2=map_to_bounds(t_temp, lower_bound, upper_bound);
     
      [lower_bound, upper_bound,y_prime_SW2];
     yp_vector_SW2(i)=y_prime_SW2;
  
%         last=y_prime_SW2;
        
        Error_vector_SW2(i)=initial-y_prime_SW2;

end
%把数据从[boundl,boundr]映射回[0,1]
     %  yp_vector_SW；3 = normalize_calibration(yp_vector_SW2, boundl, boundr);
   [epsilon_single,al];
end