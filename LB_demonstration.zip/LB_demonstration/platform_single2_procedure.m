
y0 = normalize(yy, 'range', [0, 1]);
mean_result=zeros(6,6);
distribution_result=zeros(6,6);
epsilon_vector=[0.5,1,1.5,2,2.5,3];

for g=1:1:6
resulty=single_sampling(y0,w_event_size,query_size,epsilon_vector(g));
mean_result(g,:)=resulty(1,:);
distribution_result(g,:)=resulty(2,:);
end


% Construct the full filename including the 'single', 'volume', and w_event_size
fullFilename = sprintf('%s_%s_w%d_q%d.mat', suffix, filename, w_event_size,query_size);

% Save the variables mean_result and distribution_result to the file
save(fullFilename, 'mean_result', 'distribution_result');
