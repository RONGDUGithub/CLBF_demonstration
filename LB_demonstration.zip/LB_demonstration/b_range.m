function  s=b_range(epislon_single,number)
x=1;


[fx,var1]=para_Gaussin(epislon_single,x);

ga2=power(var1,1/2);
ga1=qiwang(epislon_single,x);
ga3=exp(1-ga1)-1;

[ga2,ga3];

 s=ga2-ga3;

end
