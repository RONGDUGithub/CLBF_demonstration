function [lower_bound, upper_bound] = confidence_interval(mean, std_dev, confidence_level)
    % Calculate the Z-value from the confidence level
    Z = norminv(1 - (1 - confidence_level) / 2, 0, 1);

    % Calculate the lower and upper bounds of the confidence interval
    lower_bound = mean - (Z * std_dev);
    upper_bound = mean + (Z * std_dev);
end