mean_result=zeros(6,5);
distribution_result=zeros(6,5);
epsilon_vector=[0.5,1,1.5,2,2.5,3];

for g=1:1:6
resulty=singlei2j(yy,w_event_size,epsilon_vector(g));
mean_result(g,:)=resulty(1,:)
distribution_result(g,:)=resulty(2,:);
end

% Construct the full filename including the 'single', 'volume', and w_event_size
fullFilename = sprintf('%s_%s_w%d.mat', suffix, filename, w_event_size);

% Save the variables mean_result and distribution_result to the file
save(fullFilename, 'mean_result', 'distribution_result');

