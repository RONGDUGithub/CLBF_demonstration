  function [E2_round,Cos2_round]=smoothing_step2(y,test_sum_vector,mean_size)
number=length(y);
[rows, cols] = size(test_sum_vector);

short_edge = min(rows, cols);
for r=1:rows
yp_vector_SW=test_sum_vector(r,:);

    mean_SW(r,:)=smoothTimeSeries(yp_vector_SW,mean_size);

end


err_SW_vector=window_error(y,mean_SW);
E2_round=err_SW_vector;
D_KL = compareKL1(y, mean_SW);
Cos2_round=D_KL;

end
