function var1=expectation1(epsilon,x)
e=exp(epsilon);
S=(epsilon*e-e+1)/(2*e*(e-1-epsilon));
p=e/(2*S*e+1);
q=1/(2*S*e+1);
% % 定义自变量
fx =q/2*(2*S-4*S*x+1)+2*S*p*x;
fx2=q/3*((x-S)^3-(-S)^3+(1+S)^3-(S+x)^3)+p/3*((x+S)^3-(x-S)^3);

    

var1=fx2-fx^2;
var1 =2*p*S-S*q+q/2;
end