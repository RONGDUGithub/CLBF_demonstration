w_event_size=10;
platform_single_procedure;

w_event_size=20;
platform_single_procedure;

w_event_size=30;
platform_single_procedure;

w_event_size=40;
platform_single_procedure;

w_event_size=50; 
platform_single_procedure;

w_event_size=60;
platform_single_procedure;
