% 定义音符持续时间（以秒为单位）
t = 0.15;  % 基本时值

% 定义音符频率
E4 = 329.63;
F4 = 349.23;
F4s = 369.99;
G4 = 392.00;
G4s = 415.30;
A4 = 440.00;
A4s = 466.16;
B4 = 493.88;
C5 = 523.25;
C5s = 554.37;
D5 = 587.33;
D5s = 622.25;
E5 = 659.25;
F5 = 698.46;
F5s = 739.99;
G5 = 783.99;
A5 = 880.00;  % 添加了A5的频率
B5 = 987.77;
C6 = 1046.50;

% 采样频率
Fs = 44100;

% 创建音符函数
create_note = @(freq, dur) sin(2*pi*freq*(0:1/Fs:dur));

% 创建休止符函数
create_rest = @(dur) zeros(1, round(dur*Fs));

% 初始化空数组
melody = [];

% 第一段
melody = [melody create_note(E5, t)];
melody = [melody create_note(E5, t)];
melody = [melody create_rest(t)];
melody = [melody create_note(E5, t)];
melody = [melody create_rest(t)];
melody = [melody create_note(C5, t)];
melody = [melody create_note(E5, t*1.5)];

melody = [melody create_note(G5, t*2)];
melody = [melody create_rest(t)];
melody = [melody create_note(G4, t*2)];
melody = [melody create_rest(t)];

% 第二段
melody = [melody create_note(C5, t*1.5)];
melody = [melody create_rest(t)];
melody = [melody create_note(G4, t)];
melody = [melody create_rest(t)];
melody = [melody create_note(E4, t*1.5)];

melody = [melody create_note(A4, t)];
melody = [melody create_note(B4, t)];
melody = [melody create_note(A4s, t)];
melody = [melody create_note(A4, t)];

melody = [melody create_note(G4, t*0.75)];
melody = [melody create_note(E5, t*0.75)];
melody = [melody create_note(G5, t*0.75)];
melody = [melody create_note(A5, t)];

melody = [melody create_note(F5, t)];
melody = [melody create_note(G5, t)];
melody = [melody create_rest(t)];
melody = [melody create_note(E5, t)];

melody = [melody create_note(C5, t)];
melody = [melody create_note(D5, t)];
melody = [melody create_note(B4, t)];
melody = [melody create_rest(t)];

% 重复第一段
melody = [melody create_note(E5, t)];
melody = [melody create_note(E5, t)];
melody = [melody create_rest(t)];
melody = [melody create_note(E5, t)];
melody = [melody create_rest(t)];
melody = [melody create_note(C5, t)];
melody = [melody create_note(E5, t*1.5)];

% 添加音量调制
envelope = ones(size(melody));
attack = linspace(0, 1, round(0.02*Fs));
decay = linspace(1, 0.7, round(0.1*Fs));
envelope(1:length(attack)) = attack;
envelope(end-length(decay)+1:end) = decay;

% 应用音量调制
melody = melody .* envelope;

% 标准化音量
melody = melody / max(abs(melody));

% 播放音乐
sound(melody, Fs);