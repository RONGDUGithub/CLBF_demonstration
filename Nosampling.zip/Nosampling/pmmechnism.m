function pmvalue=pmmechnism(user_value,epsilon)
%数据映射到【-1，1】
C=(exp(epsilon/2)+1)/(exp(epsilon/2)-1);
l=((C+1)*user_value)/2-(C-1)/2;
r=l+C-1;

x=rand(1);
p=(exp(epsilon/2))/(exp(epsilon/2)+1);
if x<p
    temp0=l+(r-l)*rand(1,1);
    pmvalue=temp0;
else
     temp=(l+r)/2;
     while(temp>l&&temp<r) 
              temp=-C+(C-(-C))*rand(1);
     end
      pmvalue=temp;
end
end