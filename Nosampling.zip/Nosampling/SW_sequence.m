function yp_vector_SW=SW_sequence(y,epsilon_windows_SW)%baseline1
number=length(y);
for i=1:number
    initial=y(i);
    y_prime_SW=SW(initial,epsilon_windows_SW);
    yp_vector_SW(i)=y_prime_SW;
%     error_SW=initial-y_prime_SW;
%     Error_vector_SW(i)=error_SW;
end
%SW_sum_error=sum(abs(Error_vector_SW));
end
