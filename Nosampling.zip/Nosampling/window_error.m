function err_SW_vector=window_error(y,yp_vector)
err_SW_vector=power(mean(yp_vector')-mean(y),2);
end