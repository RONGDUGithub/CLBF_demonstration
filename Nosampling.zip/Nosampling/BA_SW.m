function record = BA_SW(epsilon, win_size, q, c_all)
    % Initialize variables
    if q < win_size
        w = q;
    else
        w = win_size;
    end

    n = length(c_all);
    o_history = nan(1, n - 1);  % Store historical outputs
    record = nan(1, n);         % Final record
    %epsilon2_hist = zeros(1, n);  % Track epsilon2 for each step

    % **Generate first output (always output the first point with Laplace noise)**
    %lambda_first = 2 * w / epsilon;  
    epsilon_first = epsilon/2/w;
    temp = SW(c_all(1),epsilon_first);
    o_history(1) = temp;
    record(1) = temp;

    epsilon2_1 = epsilon / (2 * w);  % Epsilon for the first point
    epsilon2_hist(1) = epsilon2_1;

    % **Loop through the rest of the data**
    for i = 2:n
        % **Mechanism 1**
        non_null_idx = find(~isnan(o_history(1:i-1)), 1, 'last');
        o_l = o_history(non_null_idx);
        dis = abs(o_l - c_all(i));

        %lambda_i_1 = (2 * w) / epsilon;
        epsilon_i_1 = epsilon/(2*w);

        dis = abs(SW(dis, epsilon_i_1));

        % **Mechanism 2**
        last_nonzero_epsilon_idx = find(epsilon2_hist ~= 0, 1, 'last');
        last_nonzero_epsilon = epsilon2_hist(last_nonzero_epsilon_idx);

        to_nullify = last_nonzero_epsilon / (epsilon / (2 * w)) - 1;
        if  i - non_null_idx <= to_nullify
            o_history(i) = NaN;
            record(i) = o_l;
        else
            % Determine output
            to_absorb = i - (non_null_idx + to_nullify);
            epsiloni_2 = epsilon / (2 * w) * min(to_absorb, w);
             
            %lambda_i_2 = 1 / epsiloni_2;
            %[dis, lambda_i_2]
            budget=exp(epsiloni_2);
            b=(epsiloni_2*budget-budget+1)/(2*budget*(budget-1-epsiloni_2));
           
            if dis > b
                temp = SW(c_all(i), epsiloni_2);
                o_history(i) = temp;
                epsilon2_hist(i) = epsiloni_2;
                record(i) = temp;
            else
                o_history(i) = NaN;
                record(i) = o_l;
                epsilon2_hist(i) = 0;
            end
        end
    end
end

