% temp = zeros(2,6);
% for i=1:user_number
% y_temp=yy(i,:);
% temp=temp+singlei2j(y_temp,w_event_size,epsilon_vector(g));
% end
% resulty=temp/user_number;
% 初始化变量
temp_all = zeros(2, 6, user_number);  % 为每个用户分配一个独立的 temp

for i = 1:user_number
    % 每个并行线程独立计算 temp
    y_temp = yy(:, i);
    temp= singlei2j(y_temp, w_event_size, epsilon_vector(g));
    temp_all(:, :, i) = temp;
end

% 将所有用户的结果累加
temp = sum(temp_all, 3);

% 计算最终结果
resulty = temp / user_number;