number = length(y);

Error_vector = zeros();

round=100;
E1_round = zeros(round,6);
Cos1_round = zeros(round,6);
E1_smothing = zeros(round,6);
Cos1_smothing = zeros(round,6);
E2_round = zeros(round,6);
Cos2_round = zeros(round,6);
E2_smothing = zeros(round,6);
Cos2_smothing = zeros(round,6);
parfor ii = 1:round

yp_vector_SW=SW_sequence(y,epsilon_windows_SW);

index =3;
windows_size2 = 1;
yp_vector_SW1 = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_SW,index);

index = 3;
windows_size2 = h;
yp_vector_SW2 = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_SW,index);

index = 4;
windows_size2 = h;
yp_vector_SW3 = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_SW,index);

record_BA = BA_SW(epsilon, windows_size2, windows_size2, y);
 
Toplvalue=ToPL(y,epsilon_windows_SW);

test_sum_vector = [yp_vector_SW;yp_vector_SW1;yp_vector_SW2;yp_vector_SW3;record_BA;Toplvalue];

err_SW_vector = window_error(y,test_sum_vector);
E1_round(ii,:) = err_SW_vector;

D_KL1 =compareKL1(y, test_sum_vector);
Cos1_round(ii,:) = D_KL1;

[E2_round(ii,:),Cos2_round(ii,:)]=smoothing_step2(y,test_sum_vector,smooth_size);
end

E1_final = mean(E1_round);
Cos1_final = mean(Cos1_round);
E2_final = mean(E2_round);

Cos2_final = mean(Cos2_round);
Cos3_final=[Cos1_final(1),Cos2_final(2:6)];
resulty=[E1_final;Cos3_final];
