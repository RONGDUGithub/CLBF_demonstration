function var1=para_Gaussin(epsilon,x) 
e=exp(epsilon);
S=(epsilon*e-e+1)/(2*e*(e-1-epsilon));
p=e/(2*S*e+1);
q=1/(2*S*e+1);
fx =q/2*(S^2-(-1-S+x)^2+(S+x)^2-S^2);
fx2=q/3*((-1*S)^3-(-1-S+x)^3+(S+x)^3-S^3+S^3-(-S)^3);
var1=fx2-fx^2;
%test
b=S;
var1=2*b^3*p/3-b^2*q^2+b^2*q-b*q^2+b*q-q^2/4+q/3;
end
