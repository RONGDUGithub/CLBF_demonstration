mean_SW=zeros();
mean_SW1=zeros();
mean_SW2=zeros();
%均值估计
%smothing
% mean_size=ceil(length(x)/PL/10);

%最开始的均值看起来是有问题的。
for g=1:mean_size
    mean_SW(g)=(mean(yp_vector_SW(1:g)));
    mean_SW1(g)=(mean(yp_vector_SW1(1:g)));
    mean_SW2(g)=(mean(yp_vector_SW2(1:g)));
end

for g=mean_size:number-mean_size
    mean_SW(g)=(mean(yp_vector_SW(g-mean_size+1:g+mean_size-1)));
    mean_SW1(g)=(mean(yp_vector_SW1(g-mean_size+1:g+mean_size-1)));
    mean_SW2(g)=(mean(yp_vector_SW2(g-mean_size+1:g+mean_size-1)));
end

for g=number-mean_size+1:number
    mean_SW(g)=(mean(yp_vector_SW(g:number)));
    mean_SW1(g)=(mean(yp_vector_SW1(g:number)));
    mean_SW2(g)=(mean(yp_vector_SW2(g:number)));
end
mean_SW=mapFrom01(mean_SW, 0, 1);
mean_SW1=mapFrom01(mean_SW1, 0, 1);
mean_SW2=mapFrom01(mean_SW2, 0, 1);

[sm_err_SW,sm_err_SW1,sm_err_SW2]=window_error(w_event_size,y,mean_SW,mean_SW1,mean_SW2);
[sm_best_dist, sm_D_KL] = compareKL(y,mean_SW,mean_SW1,mean_SW2);

E2_round(ii,:)=[sm_err_SW,sm_err_SW1,sm_err_SW2];
Cos2_round(ii,:)=sm_D_KL;