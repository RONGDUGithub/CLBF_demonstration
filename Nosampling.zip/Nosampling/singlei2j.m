function final3=singlei2j(yy,w_event_size,epsilon)

y0=yy;
query_size=w_event_size; 
h=query_size;


final1=zeros(1,6);
final2=zeros(1,6);
h= floor(length(yy)/40);

j=0;
smooth_size=3;
for i=1:h:length(yy)-1*w_event_size
    j=j+1;
    y=y0(i:i+w_event_size-1);
    list2;
    final1(j,:)=resulty(1,:);
    final2(j,:)=resulty(2,:);

end
t1_clean = final1(~any(isnan(final1),2),:);
t2_clean = final2(~any(isnan(final2),2),:);

if any(size(t2_clean) == 1)
    temp1=t1_clean;
    temp2 = t2_clean;
else
    temp1=mean(t1_clean);
    temp2 = mean(t2_clean);
end

final3=[temp1;temp2];
 end

