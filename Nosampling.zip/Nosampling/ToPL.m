function pmvalue=ToPL(user_value,epsilon)

for i=1:length(user_value)
     temp=user_value(i);
     temp=mapToRange2(temp);
     temp2=pmmechnism(temp,epsilon);
    % temp2=HM(temp,epsilon);
     temp3 = mapFromMinusOneToOne(temp2);
     pmvalue(i)=temp3;
end 
end