clear all;

suffix='Nonsampling';
load('volume.mat');
filename='volume';
yy=volume'; 
user_number=1;
platform_single_pre

clear all;
suffix='Nonsampling';
load('air.mat');
filename='Air';
user_number=1;
yy=air_c6h6';

platform_single_pre
% 
% clear all
% suffix='Nonsampling';
% load('Taxi.mat');
% filename='Taxi';
% yy = (ylocation - min(ylocation(:))) / (max(ylocation(:)) - min(ylocation(:)));
% user_number=1307;
% platform_single_pre
% 
% clear all;
% suffix='Nonsampling';
% load('electric.mat');
% filename='electric';
% user_number=2000;
% y0=data';
% yy = (y0 - min(y0(:))) / (max(y0(:)) - min(y0(:)));
%  platform_single_pre
music_mario