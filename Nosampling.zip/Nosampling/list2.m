flag=0;
if query_size<w_event_size
   epsilon_windows_SW = epsilon/query_size;
else
epsilon_windows_SW = epsilon/w_event_size;
flag=1;
end

epsilon_windows_SW = epsilon/w_event_size;
main;
