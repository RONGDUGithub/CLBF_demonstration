function x_compressed = compressDatah(x, lower_bound, upper_bound)
    % Function to compress data from the range (lower_bound, upper_bound) back to [0, 1]

    % Check if the bounds are valid
%     if lower_bound >= 0 || upper_bound <= 1
%           error('Invalid bounds. lower_bound must be < 0 and upper_bound must be > 1.');
%     end
   if lower_bound >0
        lower_bound = 0;
   end
    if upper_bound <1
         upper_bound =1;
    end
   
   
    % Compress the data
    x_compressed = (x - lower_bound) / (upper_bound - lower_bound);
end

