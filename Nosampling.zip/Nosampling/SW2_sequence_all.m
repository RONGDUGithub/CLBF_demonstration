function yp_vector_SW2=SW2_sequence_all(y,windows_size2,epsilon_windows_SW)
%会有error累计的问题
number=length(y);
yp_vector_SW2=zeros(1,number);
Error_vector_SW2=zeros();
error_vector_ac=zeros();

Error_vector_SW2(1)=0;

for i=1:number
    initial=y(i);
    error0=0;
    if i<=windows_size2
        error0=sum(Error_vector_SW2(1:i-1));
    else
        error0=sum(Error_vector_SW2(i-windows_size2:i-1));
    end
  %  error_vector_ac(i)=error0;
    initial_error=initial+error0;
    %截断
    if  initial_error>1
        initial_error=1;
    else
        if initial_error<0
            initial_error=0;
        end
    end

    y_prime_SW2=SW(initial_error,epsilon_windows_SW);
    yp_vector_SW2(i)=y_prime_SW2;
    %没问题，当前数据减去扰动值/类似于所有值的和-所有的扰动值的和
    Error_vector_SW2(i)=initial-y_prime_SW2;

  
end
end