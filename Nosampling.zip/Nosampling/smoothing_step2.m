  function [E2_round,Cos2_round]=smoothing_step2(y,test_sum_vector,mean_size)
number=length(y);
[rows, cols] = size(test_sum_vector);

% 比较行数和列数，选择较小的那个作为短边
short_edge = min(rows, cols);
for r=1:rows
yp_vector_SW=test_sum_vector(r,:);
%最开始的均值看起来是有问题的。
% for g=1:mean_size
%     mean_SW(r,g)=(mean(yp_vector_SW(1:g)));
% end
% 
% for g=mean_size:number-mean_size
%     mean_SW(r,g)=(mean(yp_vector_SW(g-mean_size+1:g+mean_size-1)));
% end
% 
% for g=number-mean_size+1:number
    mean_SW(r,:)=smoothTimeSeries(yp_vector_SW,mean_size);
   %mean_SW(r,:)=forwardSmoothing(yp_vector_SW, mean_size);
% end
% mean_SW_mapping=mapFrom01(mean_SW, 0, 1);
end

% alpha=2;
% mean_SW = adaptive_exponential_smoothing(yp_vector_SW, alpha);

%smoothing_vector = dynamicSmoothing(y);
err_SW_vector=window_error(y,mean_SW);
E2_round=err_SW_vector;
D_KL = compareKL1(y, mean_SW);
Cos2_round=D_KL;
%[y_meanr, SW_meanr]=window_error2(range_size2,y,mean_SW);


end

% [sm_err_SW,sm_err_SW1,sm_err_SW2]=window_error(w_event_size,y,mean_SW,mean_SW1,mean_SW2);
% [sm_best_dist, sm_D_KL] = compareKL(y,mean_SW,mean_SW1,mean_SW2);
% E2_round(ii,:)=[sm_err_SW,sm_err_SW1,sm_err_SW2];
% Cos2_round(ii,:)=sm_D_KL;