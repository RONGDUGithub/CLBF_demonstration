% w_event_size=20;
% query_size=10;
% platform_crowd_procedure;


w_event_size=20;
query_size=10;
platform_crowd_procedure;
music_mario

w_event_size=20;
query_size=30;

platform_crowd_procedure;

% % 
w_event_size=30;
query_size=10;
platform_crowd_procedure;

w_event_size=30;
query_size=40;
platform_crowd_procedure;
% 
% w_event_size=30;
% query_size=40;
% platform_crowd_procedure;
% music_mario
