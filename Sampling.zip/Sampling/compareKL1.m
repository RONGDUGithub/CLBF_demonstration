function D_kl_a = compareKL1(y, yp_vector) 
 [rows, cols] = size(yp_vector);
% 
% % 比较行数和列数，选择较小的那个作为短边
short_edge = rows;
 D_kl_a =zeros(1,rows);
% 
 for r=1:rows
%     %y0=y;
     yp_vector0=yp_vector(r,:);
%    % for g=1:length(yp_vector)-range_size
% %     y1=y0(g:range_size+g-1);
% %     y2=yp_vector0(g:range_size+g-1);
%    % temp(r,g) =temp(r,g)+cosineSim(y1,y2); 
%     D_kl_a(r)=customDTW(y,yp_vector0); 
%    % end
  D_kl_a(r)=cosineSim(y,yp_vector0); 
end
 
end