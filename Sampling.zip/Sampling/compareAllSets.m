function [kl_distances,scores]=compareAllSets(setA, setB, setC, setD, setE, setF, setG)
% 2. 计算特征分布之间的KL散度
kl_B = compare_timeseries_sets(setA, setB);
kl_C = compare_timeseries_sets(setA, setC);
kl_D = compare_timeseries_sets(setA, setD);
kl_E = compare_timeseries_sets(setA, setE);
kl_F = compare_timeseries_sets(setA, setF);
kl_G = compare_timeseries_sets(setA, setG);
kl_distances = [kl_B, kl_C, kl_D, kl_E, kl_F, kl_G];
% 将所有要比较的序列放入元胞数组
k=3;
series_to_compare = {setB, setC, setD, setE, setF, setG};

% 计算相似度分数
scores = compare_time_series_fft(setA, series_to_compare, k);
end