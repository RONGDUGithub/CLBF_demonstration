function mapped_data = map_to_bounds(data, lower_bound, upper_bound)
%     % Make sure the input is within the range [0,1]
%     if any(data < 0 | data > 1)
%         error('Input data must be within the range [0, 1].');
%     end

    % Calculate the scale factor and the shift required for the transformation
    scale = upper_bound - lower_bound;
    
    % Apply the transformation to the data
    mapped_data = (data * scale) + lower_bound;
end