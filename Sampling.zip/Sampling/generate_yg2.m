function yg = generate_yg2(y, flag)
    yg = zeros(1, length(flag));  % 初始化 yg 向量为全零向量，长度为 flag 中 1 的个数
    j=1;
    ff=0;
    for i = 1:length(flag)
        if flag(i) == 0 
            ff=1;   
            yg(i) = y(j);
        else                          
            yg(i) = y(j);
                j=j+1;    
        end
    end
end