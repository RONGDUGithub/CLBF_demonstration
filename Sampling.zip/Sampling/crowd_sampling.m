function [sn1,sn2]=crowd_sampling(y_input,user_number,slot_length,test_number,w_event_size,query_size,epsilon,random_number)

h=query_size;
s=zeros(test_number,6);
t=zeros(test_number,6);
s1=zeros(1,6);
t1=zeros(1,6);
% s4=zeros(test_number,user_number);
% s5=zeros(test_number,user_number);
%
% t1=zeros(test_number,user_number);
% t2=zeros(test_number,user_number);
% t3=zeros(test_number,user_number);
% t4=zeros(test_number,user_number);
% t5=zeros(test_number,user_number);

mean_groundtruth=zeros();
result_vector=zeros();

gaga=zeros();


tt_size=max(w_event_size,query_size);

%random_number = randi([1, user_number-(tt_size+1)], [1,test_number]);

%不理解,方案其实是一致的呀,主要做小于win_size的结果比较合理.
ylocation = y_input;



%[1490,1307]
for j1=1:user_number
    for j2=1:test_number
        hg1=random_number(j2);
        hg2=hg1+query_size-1;
        yt=ylocation(j1,hg1:hg2);
        mean_groundtruth(j2,j1)=mean(yt);
    end
end

flag=0;

for g1=1:user_number
    for g2=1:test_number
        hg1=random_number(g2);
        hg2=hg1+query_size-1;
        y_temp=ylocation(g1,hg1:hg2);
        y=y_temp;
        if query_size<w_event_size
            t_size=query_size;
            flag=1;
        else
            flag=2;
            t_size=w_event_size;
        end
        
        
        epsilon_windows_baseline=epsilon/t_size;
        epsilon_windows_SW=epsilon_windows_baseline;
        [epsilon_sampling,y_flag,sampling_number]=numberofsampling(query_size,t_size,epsilon);
        
        body1;
   
        s(g2,:)=(mean_final);
        t(g2,:)=(distribution_final);
    end
    s1(g1,:)=mean(s);
    t1(g1,:)=mean(t);
end
s1_clean = s1(~any(isnan(s1),2),:);
t1_clean = t1(~any(isnan(t1),2),:);
[rows, cols] = size(s1_clean);
min_dim1 = min(rows, cols);
[rows, cols] = size(t1_clean);
min_dim2 = min(rows, cols);
if min_dim1==1
      sn1=s1_clean;
else
    sn1=mean(s1_clean);
end
if min_dim2==1
      sn2=t1_clean;
else
  sn2=mean(t1_clean);
end

end
