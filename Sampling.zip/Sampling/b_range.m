function  s=b_range(epislon_single,number)
x=1;
%累积误差
var1=para_Gaussin(epislon_single,x);
%往外，epsilon越大，值越大
ga2=power(var1,1/2);

%往里，epsilon越大，值越小
ga1=expectation1(epislon_single,x);
ga3=exp(1-ga1)-1;

[ga2,ga3];
% s=ga2-ga3;
 s=ga3-ga2;
end
