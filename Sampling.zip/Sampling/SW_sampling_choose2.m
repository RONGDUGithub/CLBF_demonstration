function yp_vector_SW2=SW_sampling_choose2(y,epsilon_windows_SW,index,yflag)
if index==1
    %yg=SW2_sampling2(y,windows_size2,epsilon,epsilon_windows_SW,yflag)
   yp_vector_SW2=SW2_sampling2(y,epsilon_windows_SW,yflag);
end

if index==2
    %SW_sampling_dynamic2(y,vector_smooth,epsilon_single,y_flag)
  yp_vector_SW2=SW_sampling_dynamic2(y,epsilon_windows_SW,yflag);
end
end