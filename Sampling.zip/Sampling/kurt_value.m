function [varX,kurt,meanX]=kurt_value(epsilon)
e = exp(epsilon);
S = (epsilon*e - e + 1)/(2*e*(e-1-epsilon));
p = e/(2*S*e+1);
q = 1/(2*S*e+1);
b=1;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
% Generate distribution values
x = -S:0.00001:S+1;  

% PDF
f = zeros(size(x));
f(x>-S & x<=-S+b) = q; 
f(x>=-S+b & x<=S+b) = p;
f(x>b+S&x<1+S) = q;

% Mean
meanX = sum(x.*f)/sum(f);

% variance
varX = sum((x-meanX).^2.*f)/sum(f);

% Calculate the fourth central moment
mom4 = sum((x-meanX).^4.*f)/sum(f);

% Calculate kurtosis
kurt = mom4/varX^2;
end