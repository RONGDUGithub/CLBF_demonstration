function yg=SW_sequence_sampling_naive_average(y,epsilon_single,y_flag)%baseline1， SW算法
%y
ytemp=y;
y= generate_yg(ytemp, y_flag);

for i=1:length(y)
    initial0=y(i);
    y_prime_SW(i)=SW(initial0,epsilon_single);
end
%[length(y),i,y_prime_SW]
yg = generate_yg2(y_prime_SW, y_flag);
end
