y2=zeros();
smooth_size=3;
 
round=200;
Error_vector = zeros();
E1_round = zeros(round,6);
Cos1_round = zeros(round,6);
E1_smothing = zeros(round,6);
Cos1_smothing = zeros(round,6);

for ii = 1:round
if query_size<w_event_size
    epsilon_windows_baseline=epsilon/query_size;
    y_flag_base=zeros(1,query_size)+1;
else
    epsilon_windows_baseline=epsilon/w_event_size;
    y_flag_base=zeros(1,query_size)+1;
end

%SW-based
basevalue=SW_sequence_baseline(y,epsilon_windows_baseline);  


%Sampling
sampling_value=SW_sequence_sampling_naive_average(y,epsilon_sampling,y_flag);
%跑窗口为2

%APP
index = 3;
windows_size2 = query_size;
App = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_baseline,index);

%CAPP
index = 4;
windows_size2 = query_size;
Capp = SW_sequence_choose(y,windows_size2,epsilon,epsilon_windows_baseline,index);


%APP-S
index = 1;
Apps = SW_sampling_choose2(y,epsilon_sampling,index,y_flag);

%CAPP-S
index = 2;
Capps = SW_sampling_choose2(y,epsilon_sampling,index,y_flag);
kl=length(Capps);


test_sum_vector0 = [basevalue;App;Capp;sampling_value;Apps;Capps];
% vector3_1=mean(test_sum_vector0');
% Cos1_round(ii,:) = vector3_1;

err_SW_vector = window_error(y,test_sum_vector0);
E1_round(ii,:) = err_SW_vector;


D_KL1 =compareKL1(y, test_sum_vector0);
Cos1_round(ii,:) = D_KL1;


[E2_round(ii,:),Cos2_round(ii,:)]=smoothing_step2(y,test_sum_vector0,smooth_size);
end

Cos3_final=[Cos1_round(:,1:2),Cos2_round(:,3:6)];
mean_final = mean(E1_round);
distribution_final=mean(Cos3_final);


