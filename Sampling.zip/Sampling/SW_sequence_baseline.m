function yp_vector_SW=SW_sequence_baseline(y,epsilon_single)%baseline1， SW算法
yp_vector_SW=zeros();
number=length(y);
for i=1:number
    initial0=y(i);
    y_prime_SW=SW(initial0,epsilon_single);
    yp_vector_SW(i)=y_prime_SW;
end
end
