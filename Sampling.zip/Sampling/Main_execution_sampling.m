clear all; clc;
suffix='Crowd';
load('air.mat')
filename='Air';
slot_length=8990;
user_number=1;  
y_input= normalize(air_c6h6, 'range', [0, 1]);
y_input = y_input';
test_number=100;
random_number = randi([1, slot_length-(61)], [1,test_number]);
platform_crowd_pre

clear all; clc;
suffix='Crowd';
load('volume.mat')
filename='Volume';
slot_length=48204;
user_number=1;  
y_input= normalize(volume, 'range', [0, 1]);
y_input = y_input';
test_number=100;
random_number = randi([1, slot_length-(61)], [1,test_number]);
platform_crowd_pre
% % % 
% clear all; clc;
% suffix='Crowd';
% load('Taxi.mat')
% filename='Taxi';
% slot_length=1500;
% user_number=1307; 
% 
% y_input= normalize(ylocation, 'range', [0, 1]);
% 
% y_input = y_input';
% test_number=10;
% random_number = randi([1, slot_length-(61)], [1,test_number]);
% platform_crowd_pre

% clear all;
% suffix='Crowd';
% filename = 'electric';
% load([filename '.mat']);
% time_slot=96;
% slot_length=96;
% user_number=2000; 
% test_data=data';
% test_number=10;
% y_input= normalize(test_data, 'range', [0, 1]);
% y_input = y_input';
% random_number = randi([1, slot_length-(61)], [1,test_number]);
% platform_crowd_pre
% music_mario

