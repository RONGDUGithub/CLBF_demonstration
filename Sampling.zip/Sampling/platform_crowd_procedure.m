epsilon_vector=[0.5,1,1.5,2,2.5,3];
jsds_final=zeros(6,6);
distribution_final=zeros(6,6);

for g=1:1:6    
[mean_final(g,:),distribution_final(g,:)]=crowd_sampling(y_input,user_number,slot_length,test_number,w_event_size,query_size,epsilon_vector(g),random_number);
end

fullFilename = sprintf('%s_%s_w%d_q%d.mat', suffix, filename, w_event_size,query_size);

save(fullFilename, 'mean_final', 'distribution_final');
