function smoothed = smoothTimeSeries(data, windowSize)
    % Check input arguments
    if nargin < 2
        windowSize = 3;  % Default window size
    end

    % Apply moving average smoothing
    smoothed = movmean(data, [windowSize-1 0], 'Endpoints', 'shrink');
    %smoothed = movmean(smoothed, [0 windowSize-1], 'Endpoints', 'shrink');
end