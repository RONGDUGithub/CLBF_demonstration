function [epsilon_sampling,flag,t2]=numberofsampling(query_size,w_event_size,epsilon)
var_s2=zeros(1,w_event_size)+10000;

var_d=zeros(1,w_event_size);
for hj=2:1:w_event_size
     n_sampling=hj; 
     epsilon_sampling=epsilon/n_sampling;
     
     
      [flag,flag_num]=test_sampling(query_size,w_event_size,n_sampling);

      [var_s2(hj),vard(hj)]=distributionofvariance(epsilon_sampling,flag_num);
end
[t1,t2]=min(var_s2);
%t2=floor(w_event_size/3);
epsilon_sampling=epsilon/t2;
end
