function y_prime=SW(y,epsilon)
if y>1
    y=1;
end
if y<0
    y=0;
end
%budget确定了b，这个不应该做离散的应该做成连续的
budget=exp(epsilon);
b=(epsilon*budget-budget+1)/(2*budget*(budget-1-epsilon));
%high_area  S_h
p=budget/(2*b*budget+1);
%low_area  S_l
q=1/(2*b*budget+1);
%L_h,R_h
L_h=y-b;
R_h=y+b;
L_l=0-b;
R_l=1+b;
temp=rand(1,1);
if temp<p*2*b
    y_prime= L_h + (R_h-L_h)*rand(1,1);
else
    y_prime=y;
    while y_prime>=L_h&&y_prime<=R_h
    y_prime=L_l + (R_l-L_l)*rand(1,1);
    end
end
end